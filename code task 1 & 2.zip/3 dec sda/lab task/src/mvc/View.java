package mvc;

public class View {
    public void printData(String data) {
        System.out.println("Data: " + data);
    }
}

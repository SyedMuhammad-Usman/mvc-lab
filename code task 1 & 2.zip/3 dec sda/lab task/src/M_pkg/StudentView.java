package M_pkg;

public interface StudentView {
    void showStudentDetails(String studentDetails);
}

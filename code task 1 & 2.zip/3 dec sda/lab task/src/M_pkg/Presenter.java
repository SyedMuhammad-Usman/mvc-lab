package M_pkg;

import java.util.ArrayList;
import java.util.List;

public class Presenter {
    private List<Student> students; // List to store multiple students
    private StudentView view;

    public Presenter(StudentView view) {
        this.students = new ArrayList<>();
        this.view = view;
    }

    public void setStudentDetails(String name, int age, double gpa) {
        Student student = new Student();
        student.setName(name);
        student.setAge(age);
        student.setGpa(gpa);
        students.add(student);
    }

    public void updateView() {
        for (Student student : students) {
            String details = "Student Name: " + student.getName() +
                    ", Age: " + student.getAge() +
                    ", GPA: " + student.getGpa();
            view.showStudentDetails(details);
        }
    }
}

package M_pkg;

public class StudentViewImpl implements StudentView {
    @Override
    public void showStudentDetails(String studentDetails) {
        System.out.println(studentDetails);
    }
}

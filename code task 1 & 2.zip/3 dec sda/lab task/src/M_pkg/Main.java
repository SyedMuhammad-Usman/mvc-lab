package M_pkg;

public class Main {
    public static void main(String[] args) {

        StudentView view = new StudentViewImpl();
        Presenter presenter = new Presenter(view);

        presenter.setStudentDetails("Usman", 20, 3.6);
        presenter.setStudentDetails("Ali", 20, 4.0);
        presenter.setStudentDetails("Hadi", 20, 3.7);
        presenter.setStudentDetails("Umer", 20, 3.3);

        presenter.updateView();
    }
}
